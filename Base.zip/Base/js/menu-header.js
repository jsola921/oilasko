document.addEventListener("DOMContentLoaded", function () {
    // Crear un contenedor para el header
    const headerContainer = document.createElement('div');
    headerContainer.innerHTML = `
<header>
    <div class="over-header">
        <a href="index.html"><img class="logo-movil" src="img/logo-primario.svg" alt=""></a>
        
        <div class="movil-menu">
            <div></div>
            <div></div>
            <div></div>
        </div>



         <div class="menu-desktop">
            <div class="top-header">
                <a href="javascript:void(0);" role="link" class="quienes-header" id="header-productos">Productos</a>
                <ul class="menu-familias">
                    <li class="menu-item">
                        <a href="/aves.html" data-target="aves">Aves 
                            <?xml version="1.0" encoding="UTF-8"?>
                            <svg version="1.1" viewBox="0 0 2048 2048" width="128" height="128" xmlns="http://www.w3.org/2000/svg">
                            <path transform="translate(131,440)" d="m0 0h21l20 3 17 5 16 7 14 8 17 12 13 11 8 7 10 9 25 25v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2 4 4v2l4 2v2l4 2v2l4 2 4 4v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2 4 4v2l4 2v2l4 2v2l4 2 4 4v2l4 2v2l4 2v2l4 2 5 6 3 2v2l4 2v2l4 2 5 6 3 2v2l4 2 5 6 7 6v2l4 2 5 6 7 6v2l4 2 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6v2l4 2v2l4 2 5 6 7 6 5 6 7 6 4 4v2l4 2v2l4 2 34 34 6 5 7 8 9 7h2l2-3h2l2-4 247-247h2l2-4 12-12h2l2-4 12-12h2l2-4 12-12h2l2-4 12-12h2l2-4 12-12h2l2-4 28-28h2l2-4 12-12h2l2-4 12-12h2l2-4 12-12h2l2-4 12-12h2l2-4 12-12h2l2-4 12-12h2l2-4 12-12h2l2-4 12-12h2l2-4 12-12h2l2-4 48-48h2l2-4 12-12h2l2-4 12-12h2l2-4 12-12h2l2-4 12-12h2l2-4 12-12h2l2-4 12-12h2l2-4 24-24h2l2-4 76-76 8-7 11-9 17-12 20-11 20-7 24-5h22l20 3 17 5 17 7 16 10 13 10 10 9 9 11 12 17 11 22 6 16 2 7 2 1v75h-3l-1-4-4-1-7 16-9 15-10 13-12 16-14 15-11 11-5 6-49 49h-2l-2 4-8 8h-2l-1 3-6 5-3 4h-2l-2 4-6 5-5 6-7 6-5 6-6 5-3 4h-2l-1 3-7 6-6 7h-2l-1 3-7 6-6 7h-2l-1 3-6 5-3 4h-2l-2 4h-2l-1 3-6 5-3 4h-2l-2 4h-2l-1 3-6 5-3 4h-2l-2 4h-2l-1 3-6 5-3 4h-2l-2 4h-2l-1 3-6 5-7 8-6 5-5 6-5 5h-2l-1 3-6 5-3 4h-2l-2 4h-2l-1 3-5 5h-2l-2 4h-2l-2 4h-2l-1 3-5 5h-2l-2 4h-2l-2 4h-2l-1 3-5 5h-2l-2 4-8 8h-2l-2 4-12 12h-2l-2 4-512 512-11 9-15 11-15 9-14 8-16 5-33 8h-7l-2-1-1 3-11-3-28-6-16-6-16-9-14-10-14-11-12-11-8-7-843-843-7-8-10-11-13-17-11-17-10-19-2-9-2-1v-4h-2v-2h-2v-65l3 2 5-15 12-25 11-17 3-4h2l2-4 6-7 11-9 14-10 17-9 20-7z"/>
                            <path transform="translate(0,625)" d="m0 0 4 2 3 4v2h2l-1 3-7-4-1-1z"/>
                            <path transform="translate(2047,538)" d="m0 0"/>
                            <path transform="translate(3,620)" d="m0 0"/>
                            <path transform="translate(3,547)" d="m0 0"/>
                            </svg>
                        </a>
                    </li>
                    <li>|</li>
                    <li class="menu-item">
                        <a href="/vacuno.html" data-target="vacuno">Vacuno
                            <?xml version="1.0" encoding="UTF-8"?>
                            <svg version="1.1" viewBox="0 0 2048 2048" width="128" height="128" xmlns="http://www.w3.org/2000/svg">
                            <path transform="translate(131,440)" d="m0 0h21l20 3 17 5 16 7 14 8 17 12 13 11 8 7 10 9 25 25v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2 4 4v2l4 2v2l4 2v2l4 2 4 4v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2 4 4v2l4 2v2l4 2v2l4 2 4 4v2l4 2v2l4 2v2l4 2 5 6 3 2v2l4 2v2l4 2 5 6 3 2v2l4 2 5 6 7 6v2l4 2 5 6 7 6v2l4 2 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6v2l4 2v2l4 2 5 6 7 6 5 6 7 6 4 4v2l4 2v2l4 2 34 34 6 5 7 8 9 7h2l2-3h2l2-4 247-247h2l2-4 12-12h2l2-4 12-12h2l2-4 12-12h2l2-4 12-12h2l2-4 12-12h2l2-4 28-28h2l2-4 12-12h2l2-4 12-12h2l2-4 12-12h2l2-4 12-12h2l2-4 12-12h2l2-4 12-12h2l2-4 12-12h2l2-4 12-12h2l2-4 12-12h2l2-4 48-48h2l2-4 12-12h2l2-4 12-12h2l2-4 12-12h2l2-4 12-12h2l2-4 12-12h2l2-4 12-12h2l2-4 24-24h2l2-4 76-76 8-7 11-9 17-12 20-11 20-7 24-5h22l20 3 17 5 17 7 16 10 13 10 10 9 9 11 12 17 11 22 6 16 2 7 2 1v75h-3l-1-4-4-1-7 16-9 15-10 13-12 16-14 15-11 11-5 6-49 49h-2l-2 4-8 8h-2l-1 3-6 5-3 4h-2l-2 4-6 5-5 6-7 6-5 6-6 5-3 4h-2l-1 3-7 6-6 7h-2l-1 3-7 6-6 7h-2l-1 3-6 5-3 4h-2l-2 4h-2l-1 3-6 5-3 4h-2l-2 4h-2l-1 3-6 5-3 4h-2l-2 4h-2l-1 3-6 5-3 4h-2l-2 4h-2l-1 3-6 5-7 8-6 5-5 6-5 5h-2l-1 3-6 5-3 4h-2l-2 4h-2l-1 3-5 5h-2l-2 4h-2l-2 4h-2l-1 3-5 5h-2l-2 4h-2l-2 4h-2l-1 3-5 5h-2l-2 4-8 8h-2l-2 4-12 12h-2l-2 4-512 512-11 9-15 11-15 9-14 8-16 5-33 8h-7l-2-1-1 3-11-3-28-6-16-6-16-9-14-10-14-11-12-11-8-7-843-843-7-8-10-11-13-17-11-17-10-19-2-9-2-1v-4h-2v-2h-2v-65l3 2 5-15 12-25 11-17 3-4h2l2-4 6-7 11-9 14-10 17-9 20-7z"/>
                            <path transform="translate(0,625)" d="m0 0 4 2 3 4v2h2l-1 3-7-4-1-1z"/>
                            <path transform="translate(2047,538)" d="m0 0"/>
                            <path transform="translate(3,620)" d="m0 0"/>
                            <path transform="translate(3,547)" d="m0 0"/>
                            </svg>
                        </a>
                    </li>
                    <li>|</li>
                    <li class="menu-item">
                        <a href="/porcino.html" data-target="porcino">Porcino
                            <?xml version="1.0" encoding="UTF-8"?>
                            <svg version="1.1" viewBox="0 0 2048 2048" width="128" height="128" xmlns="http://www.w3.org/2000/svg">
                            <path transform="translate(131,440)" d="m0 0h21l20 3 17 5 16 7 14 8 17 12 13 11 8 7 10 9 25 25v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2 4 4v2l4 2v2l4 2v2l4 2 4 4v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2 4 4v2l4 2v2l4 2v2l4 2 4 4v2l4 2v2l4 2v2l4 2 5 6 3 2v2l4 2v2l4 2 5 6 3 2v2l4 2 5 6 7 6v2l4 2 5 6 7 6v2l4 2 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6v2l4 2v2l4 2 5 6 7 6 5 6 7 6 4 4v2l4 2v2l4 2 34 34 6 5 7 8 9 7h2l2-3h2l2-4 247-247h2l2-4 12-12h2l2-4 12-12h2l2-4 12-12h2l2-4 12-12h2l2-4 12-12h2l2-4 28-28h2l2-4 12-12h2l2-4 12-12h2l2-4 12-12h2l2-4 12-12h2l2-4 12-12h2l2-4 12-12h2l2-4 12-12h2l2-4 12-12h2l2-4 12-12h2l2-4 48-48h2l2-4 12-12h2l2-4 12-12h2l2-4 12-12h2l2-4 12-12h2l2-4 12-12h2l2-4 12-12h2l2-4 24-24h2l2-4 76-76 8-7 11-9 17-12 20-11 20-7 24-5h22l20 3 17 5 17 7 16 10 13 10 10 9 9 11 12 17 11 22 6 16 2 7 2 1v75h-3l-1-4-4-1-7 16-9 15-10 13-12 16-14 15-11 11-5 6-49 49h-2l-2 4-8 8h-2l-1 3-6 5-3 4h-2l-2 4-6 5-5 6-7 6-5 6-6 5-3 4h-2l-1 3-7 6-6 7h-2l-1 3-7 6-6 7h-2l-1 3-6 5-3 4h-2l-2 4h-2l-1 3-6 5-3 4h-2l-2 4h-2l-1 3-6 5-3 4h-2l-2 4h-2l-1 3-6 5-3 4h-2l-2 4h-2l-1 3-6 5-7 8-6 5-5 6-5 5h-2l-1 3-6 5-3 4h-2l-2 4h-2l-1 3-5 5h-2l-2 4h-2l-2 4h-2l-1 3-5 5h-2l-2 4h-2l-2 4h-2l-1 3-5 5h-2l-2 4-8 8h-2l-2 4-12 12h-2l-2 4-512 512-11 9-15 11-15 9-14 8-16 5-33 8h-7l-2-1-1 3-11-3-28-6-16-6-16-9-14-10-14-11-12-11-8-7-843-843-7-8-10-11-13-17-11-17-10-19-2-9-2-1v-4h-2v-2h-2v-65l3 2 5-15 12-25 11-17 3-4h2l2-4 6-7 11-9 14-10 17-9 20-7z"/>
                            <path transform="translate(0,625)" d="m0 0 4 2 3 4v2h2l-1 3-7-4-1-1z"/>
                            <path transform="translate(2047,538)" d="m0 0"/>
                            <path transform="translate(3,620)" d="m0 0"/>
                            <path transform="translate(3,547)" d="m0 0"/>
                            </svg>
                        </a>
                    </li>
                    <li>|</li>
                    <li class="menu-item">
                        <a href="/ovino.html" data-target="ovino">Ovino
                            <?xml version="1.0" encoding="UTF-8"?>
                            <svg version="1.1" viewBox="0 0 2048 2048" width="128" height="128" xmlns="http://www.w3.org/2000/svg">
                            <path transform="translate(131,440)" d="m0 0h21l20 3 17 5 16 7 14 8 17 12 13 11 8 7 10 9 25 25v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2 4 4v2l4 2v2l4 2v2l4 2 4 4v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2v2l4 2 4 4v2l4 2v2l4 2v2l4 2 4 4v2l4 2v2l4 2v2l4 2 5 6 3 2v2l4 2v2l4 2 5 6 3 2v2l4 2 5 6 7 6v2l4 2 5 6 7 6v2l4 2 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6v2l4 2v2l4 2 5 6 7 6 5 6 7 6 4 4v2l4 2v2l4 2 34 34 6 5 7 8 9 7h2l2-3h2l2-4 247-247h2l2-4 12-12h2l2-4 12-12h2l2-4 12-12h2l2-4 12-12h2l2-4 12-12h2l2-4 28-28h2l2-4 12-12h2l2-4 12-12h2l2-4 12-12h2l2-4 12-12h2l2-4 12-12h2l2-4 12-12h2l2-4 12-12h2l2-4 12-12h2l2-4 12-12h2l2-4 48-48h2l2-4 12-12h2l2-4 12-12h2l2-4 12-12h2l2-4 12-12h2l2-4 12-12h2l2-4 12-12h2l2-4 24-24h2l2-4 76-76 8-7 11-9 17-12 20-11 20-7 24-5h22l20 3 17 5 17 7 16 10 13 10 10 9 9 11 12 17 11 22 6 16 2 7 2 1v75h-3l-1-4-4-1-7 16-9 15-10 13-12 16-14 15-11 11-5 6-49 49h-2l-2 4-8 8h-2l-1 3-6 5-3 4h-2l-2 4-6 5-5 6-7 6-5 6-6 5-3 4h-2l-1 3-7 6-6 7h-2l-1 3-7 6-6 7h-2l-1 3-6 5-3 4h-2l-2 4h-2l-1 3-6 5-3 4h-2l-2 4h-2l-1 3-6 5-3 4h-2l-2 4h-2l-1 3-6 5-3 4h-2l-2 4h-2l-1 3-6 5-7 8-6 5-5 6-5 5h-2l-1 3-6 5-3 4h-2l-2 4h-2l-1 3-5 5h-2l-2 4h-2l-2 4h-2l-1 3-5 5h-2l-2 4h-2l-2 4h-2l-1 3-5 5h-2l-2 4-8 8h-2l-2 4-12 12h-2l-2 4-512 512-11 9-15 11-15 9-14 8-16 5-33 8h-7l-2-1-1 3-11-3-28-6-16-6-16-9-14-10-14-11-12-11-8-7-843-843-7-8-10-11-13-17-11-17-10-19-2-9-2-1v-4h-2v-2h-2v-65l3 2 5-15 12-25 11-17 3-4h2l2-4 6-7 11-9 14-10 17-9 20-7z"/>
                            <path transform="translate(0,625)" d="m0 0 4 2 3 4v2h2l-1 3-7-4-1-1z"/>
                            <path transform="translate(2047,538)" d="m0 0"/>
                            <path transform="translate(3,620)" d="m0 0"/>
                            <path transform="translate(3,547)" d="m0 0"/>
                            </svg>
                        </a>
                    </li>
                    <li>|</li>
                    <li class="menu-item">
                        <a href="#">Caza
                        </a>
                    </li>
                    <li>|</li>
                    <li class="menu-item">
                        <a href="#">Elaborados
                        </a>
                    </li>
                    <li>|</li>
                    <li class="menu-item">
                        <a href="#">Congelados
                        </a>
                    </li>
                </ul>
            <a href="" class="quienes-header">Servicios</a>
            <a href="index.html"><img class="logo-desktop" src="img/logo-primario.svg" alt=""></a>
            <a href="" class="quienes-header">Quénes Somos</a>
            <a href="" class="quienes-header">Contacto</a>
            </div>
                

            
        </div>

    </div>

    <!-- DESKTOP AVES -->
    <div class="submenu" id="aves">
        <p><a href="/aves.html">Aves</a></p>
        <ul class="sub-submenu">
            <li><a href="/aves.html#pollo">Pollo</a>
                <ul>
                    <li> <a href="/aves.html#blanco">Blanco</a></li>
                    <li> <a href="/aves.html#amarillo">Amarillo</a></li>
                    <li> <a href="/aves.html#certificado">Certificado</a></li>
                    <li> <a href="/aves.html#pollo">Ver todo</a></li>
                </ul>
            </li>
            <li><a href="/aves.html#pavo">Pavo</a>
                <ul>
                    <li><a href="/aves.html#destaPavo">Destacados</a></li>
                    <li><a href="/aves.html#pavo">Ver todo</a></li>
                </ul>
            </li>
            <li><a href="/aves.html#corral">Corral</a>
                <ul>
                    <li><a href="/aves.html#destaCorral">Destacados</a></li>
                    <li><a href="/aves.html#corral">Ver todo</a></li>
                </ul>
            </li>
            <li><a href="/aves.html#huevos">Huevos</a>
                <ul>
                    <li><a href="/aves.html#huevos">Ver todo</a></li>
                </ul>
             </li>
        </ul>
        <img src="img/oilasko-berriak-aves-portada.webp" alt="">
    </div>

    <!-- DESKTOP VACUNO -->
    <div class="submenu" id="vacuno">
        <p><a href="vacuno.html">VACUNO</a></p>
        <ul  class="sub-submenu">
            <li><a href="/vacuno.html#vaca">Vaca</a>
                <ul>
                    <li><a href="/vacuno.htm#destaVaca">Destacados</a></li>
                    <li><a href="/vacuno.html#vaca"></a>Ver todo</li>
                </ul>
            </li>
            <li><a href="vacuno.html#ternera">Ternera</a>
                <ul>
                    <li><a href="vacuno.html#destaTernera">Destacados</a></li>
                    <li><a href="vacuno.html#ternera">Ver todo</a></li>
                </ul>
            </li>
            <li><a href="vacuno.html#casqueria">Casqueria</a>
                <ul>
                    <li><a href="vacuno.html#destaCasque">Destacados</a></li>
                    <li><a href="vacuno.html#casque"></a>Ver todo</li>
                </ul>
            </li>
        </ul>
        <img src="img/oilasko-berriak-vacuno-portada.webp" alt="">
    </div>

    <!-- DESKTOP PORCINO -->
    <div class="submenu" id="porcino">
        <p><a href="porcino.html">PORCINO</a></p>
        <ul  class="sub-submenu">
            <li><a href="porcino.html#blanco">Blanco</a>
                <ul>
                    <li><a href="porcino.html#destaBlanco">Destacados</a></li>
                    <li><a href="porcino.html#blanco">Ver todo</a></li>
                </ul>
            </li>
            <li><a href="porcino.html#duroc"></a>Duroc
                <ul>
                    <li><a href="porcino.html#destaDuroc">Destacados</a></li>
                    <li><a href="porcino.html#duroc">Ver todo</a></li>
                </ul>
            </li>
            <li><a href="porcino.html#royal">Royal</a>
                <ul>
                    <li><a href="porcino.html#destaRoyal">Destacados</a></li>
                    <li><a href="porcino.html#royal">Ver todo</a></li>
                </ul>
            </li>
            <li><a href="porcino.html#iderico">Iberico</a>
                <ul>
                    <li><a href="porcino.html#destaIderico">Destacados</a></li>
                    <li><a href="porcino.html#iberico">Ver todo</a></li>
                </ul>
            </li>
            <li><a href="porcino.html#casqueria">Casquería</a>
                <ul>
                    <li><a href="porcino.html#destaCasqueria">Destacados</a></li>
                    <li><a href="porcino.html#casqueria">Ver todo</a></li>
                </ul>
            </li>
        </ul>
        <img src="img/oilasko-berriak-porcino-portada.webp" alt="">
    </div>

    <!-- DESKTOP OVINO -->
    <div class="submenu" id="ovino">
        <p><a href="ovino.html">OVINO</a></p>
        <ul class="sub-submenu">
            <li><a href="ovino.html#lechazo">Lechazo</a>
                <ul>
                    <li><a href="ovino.html#destaLechazo">Destacados</a></li>
                    <li><a href="ovino.html#lechazo">Ver todo</a></li>
                </ul>
            </li>
            <li><a href="ovino.html#recental">Recental</a>
                <ul>
                    <li><a href="ovino.html#destarecental">Destacados</a></li>
                    <li><a href="ovino.html#recental">Ver todo</a></li>
                </ul>
            </li>
            <li><a href="ovino.html#cordero">Cordero</a>
                <ul>
                    <li><a href="ovino.html#destaCordero">Destacados</a></li>
                    <li><a href="ovino.html#cordero">Ver todo</a></li>
                </ul>
            </li>
            <li><a href="ovino.html">Casquería</a>
                <ul>
                    <li><a href="ovino.html#destaCasqueria">Destacados</a></li>
                    <li><a href="ovino.html#casqueria">Ver todo</a></li>
                </ul>
            </li>
        </ul>
        <img src="img/oilasko-berriak-ovino-portada.webp" alt="">
    </div>
   

    <div class="menu-container-movil">
        <!-- Nivel 1 -->
        <div class="menu active" id="menu-level-1">
          <ul class="menu-principal">
            <li data-target="#menu-level-2-aves">Aves <span>></span></li>
            <li data-target="#menu-level-2-vacuno">Vacuno <span>></span></li>
            <li data-target="#menu-level-2-porcino">Porcino <span>></span></li>
            <li data-target="#menu-level-2-ovino">Ovino <span>></span></li>
            <li data-target="#menu-level-2-caza">Caza <span>></span></li>
            <li data-target="#menu-level-2-elaborados">Elaborados <span>></span></li>
            <li data-target="#menu-level-2-congelados">Congelados <span>></span></li>
            <li><a href="/servicios">Servicios</a></li>
            <li><a href="/quienes-somos">Quienes Somos</a></li>
            <li><a href="/contacto">Contacto</a></li>
          </ul>

          
        </div>
      
        <!-- Nivel 2: Aves -->
        <div class="menu" id="menu-level-2-aves">
            <div class="title">
                <div class="back-btn" data-back="#menu-level-1"><?xml version="1.0" encoding="UTF-8"?>
                    <svg version="1.1" viewBox="0 0 2048 2048" width="512" height="512" xmlns="http://www.w3.org/2000/svg">
                    <path transform="translate(1531,509)" d="m0 0h9l13 4 10 7 9 7 4 4v2h2v2h2v2h2v2h2l6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 7 8 23 23 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 7 8 9 13 4 9v25l-3 4-10 15-6 7-7 6-5 6-8 7-445 445-12 7-10 3-13 1-15-4-11-8-7-7-8-16-1-7v-12l4-13 6-9 13-15 373-373h2l1-3-1842-1-14-3-8-4-10-8-7-10-4-8-1-4v-20l4-9 6-10 6-7 11-7 15-4h1609l153-1h81l-7-8-14-14v-2l-4-2v-2l-4-2v-2l-4-2v-2l-4-2v-2l-4-2v-2h-2l-6-7-6-5-6-7-6-5-6-7-6-5-7-8-300-300-8-13-3-7-1-6v-13l4-13 6-9 7-8 12-7 7-2z"/>
                    <path transform="translate(2047,1009)" d="m0 0"/>
                    </svg>
                </div>
              <p>AVES</p>
            </div>
          
          <ul>
            <li data-target="#menu-level-3-pollo">Pollo <span>></span></li>
            <li data-target="#menu-level-3-pavo"><a href="/aves.html#pavo"></a>Pavo <span>></span></li>
            <li data-target="#menu-level-3-corral"><a href="/aves.html#corral"></a>Corral <span>></span></li>
            <li>Huevos</li>
          </ul>
        </div>
      
            <!-- Nivel 3: Pollo -->
            <div class="menu" id="menu-level-3-pollo">
                <div class="title">
                    <div class="back-btn" data-back="#menu-level-2-aves"><?xml version="1.0" encoding="UTF-8"?>
                        <svg version="1.1" viewBox="0 0 2048 2048" width="512" height="512" xmlns="http://www.w3.org/2000/svg">
                        <path transform="translate(1531,509)" d="m0 0h9l13 4 10 7 9 7 4 4v2h2v2h2v2h2v2h2l6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 7 8 23 23 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 7 8 9 13 4 9v25l-3 4-10 15-6 7-7 6-5 6-8 7-445 445-12 7-10 3-13 1-15-4-11-8-7-7-8-16-1-7v-12l4-13 6-9 13-15 373-373h2l1-3-1842-1-14-3-8-4-10-8-7-10-4-8-1-4v-20l4-9 6-10 6-7 11-7 15-4h1609l153-1h81l-7-8-14-14v-2l-4-2v-2l-4-2v-2l-4-2v-2l-4-2v-2l-4-2v-2h-2l-6-7-6-5-6-7-6-5-6-7-6-5-7-8-300-300-8-13-3-7-1-6v-13l4-13 6-9 7-8 12-7 7-2z"/>
                        <path transform="translate(2047,1009)" d="m0 0"/>
                        </svg>
                    </div>
                <p>POLLO</p>
                </div>
            <ul>
                <li><a href="/aves.html#blanco">Blanco</a></li>
                <li><a href="/aves.html#amarillo">Amarillo</a></li>
                <li><a href="/aves.html#certificado">Certificado</a></li>
            </ul>
            </div>
        
            <!-- Nivel 3: Pavo -->
            <div class="menu" id="menu-level-3-pavo">
                <div class="title">
                    <div class="back-btn" data-back="#menu-level-2-aves"><?xml version="1.0" encoding="UTF-8"?>
                        <svg version="1.1" viewBox="0 0 2048 2048" width="512" height="512" xmlns="http://www.w3.org/2000/svg">
                        <path transform="translate(1531,509)" d="m0 0h9l13 4 10 7 9 7 4 4v2h2v2h2v2h2v2h2l6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 7 8 23 23 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 7 8 9 13 4 9v25l-3 4-10 15-6 7-7 6-5 6-8 7-445 445-12 7-10 3-13 1-15-4-11-8-7-7-8-16-1-7v-12l4-13 6-9 13-15 373-373h2l1-3-1842-1-14-3-8-4-10-8-7-10-4-8-1-4v-20l4-9 6-10 6-7 11-7 15-4h1609l153-1h81l-7-8-14-14v-2l-4-2v-2l-4-2v-2l-4-2v-2l-4-2v-2l-4-2v-2h-2l-6-7-6-5-6-7-6-5-6-7-6-5-7-8-300-300-8-13-3-7-1-6v-13l4-13 6-9 7-8 12-7 7-2z"/>
                        <path transform="translate(2047,1009)" d="m0 0"/>
                        </svg>
                    </div>
                <p><a href="/aves.html#pavo">PAVO</a></p>
                </div>
            <!-- <ul>
                <li>Pavo 1</li>
                <li>Pavo 2</li>
            </ul> -->
            </div>
        
            <!-- Nivel 3: Corral -->
            <div class="menu" id="menu-level-3-corral">
                <div class="title">
                    <div class="back-btn" data-back="#menu-level-2-aves"><?xml version="1.0" encoding="UTF-8"?>
                        <svg version="1.1" viewBox="0 0 2048 2048" width="512" height="512" xmlns="http://www.w3.org/2000/svg">
                        <path transform="translate(1531,509)" d="m0 0h9l13 4 10 7 9 7 4 4v2h2v2h2v2h2v2h2l6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 7 8 23 23 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 7 8 9 13 4 9v25l-3 4-10 15-6 7-7 6-5 6-8 7-445 445-12 7-10 3-13 1-15-4-11-8-7-7-8-16-1-7v-12l4-13 6-9 13-15 373-373h2l1-3-1842-1-14-3-8-4-10-8-7-10-4-8-1-4v-20l4-9 6-10 6-7 11-7 15-4h1609l153-1h81l-7-8-14-14v-2l-4-2v-2l-4-2v-2l-4-2v-2l-4-2v-2l-4-2v-2h-2l-6-7-6-5-6-7-6-5-6-7-6-5-7-8-300-300-8-13-3-7-1-6v-13l4-13 6-9 7-8 12-7 7-2z"/>
                        <path transform="translate(2047,1009)" d="m0 0"/>
                        </svg>
                    </div>
                <p><a href="/aves.html#corral">CORRAL</a></p>
                </div>
            <!-- <ul>
                <li>Perdiz</li>
                <li>Codorniz</li>
                <li>Corral 2</li>
            </ul> -->
            </div>
      
        <!-- Nivel 2: Vacuno -->
        <div class="menu" id="menu-level-2-vacuno">
            <div class="title">
                <div class="back-btn" data-back="#menu-level-1"><?xml version="1.0" encoding="UTF-8"?>
                    <svg version="1.1" viewBox="0 0 2048 2048" width="512" height="512" xmlns="http://www.w3.org/2000/svg">
                    <path transform="translate(1531,509)" d="m0 0h9l13 4 10 7 9 7 4 4v2h2v2h2v2h2v2h2l6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 7 8 23 23 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 7 8 9 13 4 9v25l-3 4-10 15-6 7-7 6-5 6-8 7-445 445-12 7-10 3-13 1-15-4-11-8-7-7-8-16-1-7v-12l4-13 6-9 13-15 373-373h2l1-3-1842-1-14-3-8-4-10-8-7-10-4-8-1-4v-20l4-9 6-10 6-7 11-7 15-4h1609l153-1h81l-7-8-14-14v-2l-4-2v-2l-4-2v-2l-4-2v-2l-4-2v-2l-4-2v-2h-2l-6-7-6-5-6-7-6-5-6-7-6-5-7-8-300-300-8-13-3-7-1-6v-13l4-13 6-9 7-8 12-7 7-2z"/>
                    <path transform="translate(2047,1009)" d="m0 0"/>
                    </svg>
                </div>
              <p>VACUNO</p>
            </div>
          <ul>
            <li data-target="#menu-level-3-vaca"><a href="/vacuno.html#vaca"></a>Vaca <span>></span></li>
            <li data-target="#menu-level-3-ternera"><a href="/vacuno.html#ternera"></a>Ternera <span>></span></li>
            <li data-target="#menu-level-3-casqueria-vacuno"><a href="/vacuno.html#casqueria"></a>Casquería <span>></span></li>
          </ul>
        </div>
      
            <!-- Nivel 3: Vaca -->
            <div class="menu" id="menu-level-3-vaca">
                <div class="title">
                    <div class="back-btn" data-back="#menu-level-2-vacuno"><?xml version="1.0" encoding="UTF-8"?>
                        <svg version="1.1" viewBox="0 0 2048 2048" width="512" height="512" xmlns="http://www.w3.org/2000/svg">
                        <path transform="translate(1531,509)" d="m0 0h9l13 4 10 7 9 7 4 4v2h2v2h2v2h2v2h2l6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 7 8 23 23 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 7 8 9 13 4 9v25l-3 4-10 15-6 7-7 6-5 6-8 7-445 445-12 7-10 3-13 1-15-4-11-8-7-7-8-16-1-7v-12l4-13 6-9 13-15 373-373h2l1-3-1842-1-14-3-8-4-10-8-7-10-4-8-1-4v-20l4-9 6-10 6-7 11-7 15-4h1609l153-1h81l-7-8-14-14v-2l-4-2v-2l-4-2v-2l-4-2v-2l-4-2v-2l-4-2v-2h-2l-6-7-6-5-6-7-6-5-6-7-6-5-7-8-300-300-8-13-3-7-1-6v-13l4-13 6-9 7-8 12-7 7-2z"/>
                        <path transform="translate(2047,1009)" d="m0 0"/>
                        </svg>
                    </div>
                <p><a href="/vacuno.html#vaca">VACA</a></p>
                </div>
            <!-- <ul>
                <li>Canal</li>
                <li>Pistola</li>
                <li>Falda</li>
                <li>Bola</li>
                <li>Cinta</li>
                <li>Rabo</li>
                <li>Ver todo</li>
            </ul> -->
            </div>
        
            <!-- Nivel 3: Ternera -->
            <div class="menu" id="menu-level-3-ternera">
                <div class="title">
                    <div class="back-btn" data-back="#menu-level-2-vacuno"><?xml version="1.0" encoding="UTF-8"?>
                        <svg version="1.1" viewBox="0 0 2048 2048" width="512" height="512" xmlns="http://www.w3.org/2000/svg">
                        <path transform="translate(1531,509)" d="m0 0h9l13 4 10 7 9 7 4 4v2h2v2h2v2h2v2h2l6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 7 8 23 23 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 7 8 9 13 4 9v25l-3 4-10 15-6 7-7 6-5 6-8 7-445 445-12 7-10 3-13 1-15-4-11-8-7-7-8-16-1-7v-12l4-13 6-9 13-15 373-373h2l1-3-1842-1-14-3-8-4-10-8-7-10-4-8-1-4v-20l4-9 6-10 6-7 11-7 15-4h1609l153-1h81l-7-8-14-14v-2l-4-2v-2l-4-2v-2l-4-2v-2l-4-2v-2l-4-2v-2h-2l-6-7-6-5-6-7-6-5-6-7-6-5-7-8-300-300-8-13-3-7-1-6v-13l4-13 6-9 7-8 12-7 7-2z"/>
                        <path transform="translate(2047,1009)" d="m0 0"/>
                        </svg>
                    </div>
                <p><a href="/vacuno.html#ternera">TERNERA</a></p>
                </div>
            <!-- <ul>
                <li>Canal</li>
                <li>Pistola</li>
                <li>Falda</li>
                <li>Bola</li>
                <li>Cinta</li>
                <li>Rabo</li>
                <li>Ver todo</li>
            </ul> -->
            </div>
        
            <!-- Nivel 3: Casquería Vacuno -->
            <div class="menu" id="menu-level-3-casqueria-vacuno">
                <div class="title">
                    <div class="back-btn" data-back="#menu-level-2-vacuno"><?xml version="1.0" encoding="UTF-8"?>
                        <svg version="1.1" viewBox="0 0 2048 2048" width="512" height="512" xmlns="http://www.w3.org/2000/svg">
                        <path transform="translate(1531,509)" d="m0 0h9l13 4 10 7 9 7 4 4v2h2v2h2v2h2v2h2l6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 7 8 23 23 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 7 8 9 13 4 9v25l-3 4-10 15-6 7-7 6-5 6-8 7-445 445-12 7-10 3-13 1-15-4-11-8-7-7-8-16-1-7v-12l4-13 6-9 13-15 373-373h2l1-3-1842-1-14-3-8-4-10-8-7-10-4-8-1-4v-20l4-9 6-10 6-7 11-7 15-4h1609l153-1h81l-7-8-14-14v-2l-4-2v-2l-4-2v-2l-4-2v-2l-4-2v-2l-4-2v-2h-2l-6-7-6-5-6-7-6-5-6-7-6-5-7-8-300-300-8-13-3-7-1-6v-13l4-13 6-9 7-8 12-7 7-2z"/>
                        <path transform="translate(2047,1009)" d="m0 0"/>
                        </svg>
                    </div>
                <p><a href="/vacuno.html#casqueria">CASQUERIA</a></p>
                </div>
            <!-- <ul>
                <li>Estómago</li>
                <li>Intestinos</li>
                <li>Hígado</li>
                <li>Riñones</li>
                <li>Sesos</li>
                <li>Corazón</li>
                <li>Ver todo</li>
            </ul> -->
            </div>
      
        <!-- Nivel 2: Porcino -->
        <div class="menu" id="menu-level-2-porcino">
            <div class="title">
                <div class="back-btn" data-back="#menu-level-1"><?xml version="1.0" encoding="UTF-8"?>
                    <svg version="1.1" viewBox="0 0 2048 2048" width="512" height="512" xmlns="http://www.w3.org/2000/svg">
                    <path transform="translate(1531,509)" d="m0 0h9l13 4 10 7 9 7 4 4v2h2v2h2v2h2v2h2l6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 7 8 23 23 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 7 8 9 13 4 9v25l-3 4-10 15-6 7-7 6-5 6-8 7-445 445-12 7-10 3-13 1-15-4-11-8-7-7-8-16-1-7v-12l4-13 6-9 13-15 373-373h2l1-3-1842-1-14-3-8-4-10-8-7-10-4-8-1-4v-20l4-9 6-10 6-7 11-7 15-4h1609l153-1h81l-7-8-14-14v-2l-4-2v-2l-4-2v-2l-4-2v-2l-4-2v-2l-4-2v-2h-2l-6-7-6-5-6-7-6-5-6-7-6-5-7-8-300-300-8-13-3-7-1-6v-13l4-13 6-9 7-8 12-7 7-2z"/>
                    <path transform="translate(2047,1009)" d="m0 0"/>
                    </svg>
                </div>
              <p>PORCINO</p>
            </div>
          <ul>
            <li data-target="#menu-level-3-blanco"><a href="/porcino.html#blanco"></a>Blanco<span>></span></li>
            <li data-target="#menu-level-3-duroc"><a href="/porcino.html#duroc"></a>Duroc<span>></span></li>
            <li data-target="#menu-level-3-royal"><a href="/porcino.html#royal"></a>Royal<span>></span></li>
            <li data-target="#menu-level-3-iberico"><a href="/porcino.html#iberico"></a>Ibérico<span>></span></li>
            <li data-target="#menu-level-3-casqueria-porcino"><a href="/porcino.html#casqueria"></a>Casquería<span>></span></li>
          </ul>
        </div>

            <!-- Nivel 3: Blanco -->
            <!-- <div class="menu" id="menu-level-3-blanco">
                <div class="title">
                    <div class="back-btn" data-back="#menu-level-2-porcino"><?xml version="1.0" encoding="UTF-8"?>
                        <svg version="1.1" viewBox="0 0 2048 2048" width="512" height="512" xmlns="http://www.w3.org/2000/svg">
                        <path transform="translate(1531,509)" d="m0 0h9l13 4 10 7 9 7 4 4v2h2v2h2v2h2v2h2l6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 7 8 23 23 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 7 8 9 13 4 9v25l-3 4-10 15-6 7-7 6-5 6-8 7-445 445-12 7-10 3-13 1-15-4-11-8-7-7-8-16-1-7v-12l4-13 6-9 13-15 373-373h2l1-3-1842-1-14-3-8-4-10-8-7-10-4-8-1-4v-20l4-9 6-10 6-7 11-7 15-4h1609l153-1h81l-7-8-14-14v-2l-4-2v-2l-4-2v-2l-4-2v-2l-4-2v-2l-4-2v-2h-2l-6-7-6-5-6-7-6-5-6-7-6-5-7-8-300-300-8-13-3-7-1-6v-13l4-13 6-9 7-8 12-7 7-2z"/>
                        <path transform="translate(2047,1009)" d="m0 0"/>
                        </svg>
                    </div>
                <p>BLANCO</p>
                </div>
                <ul>
                <li>Blanco 1</li>
                <li>Blanco 2</li>
                <li>Ver todo</li>
                </ul>
            </div> -->

            <!-- Nivel 3: Duroc -->
            <!-- <div class="menu" id="menu-level-3-duroc">
                <div class="title">
                    <div class="back-btn" data-back="#menu-level-2-porcino"><?xml version="1.0" encoding="UTF-8"?>
                        <svg version="1.1" viewBox="0 0 2048 2048" width="512" height="512" xmlns="http://www.w3.org/2000/svg">
                        <path transform="translate(1531,509)" d="m0 0h9l13 4 10 7 9 7 4 4v2h2v2h2v2h2v2h2l6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 7 8 23 23 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 7 8 9 13 4 9v25l-3 4-10 15-6 7-7 6-5 6-8 7-445 445-12 7-10 3-13 1-15-4-11-8-7-7-8-16-1-7v-12l4-13 6-9 13-15 373-373h2l1-3-1842-1-14-3-8-4-10-8-7-10-4-8-1-4v-20l4-9 6-10 6-7 11-7 15-4h1609l153-1h81l-7-8-14-14v-2l-4-2v-2l-4-2v-2l-4-2v-2l-4-2v-2l-4-2v-2h-2l-6-7-6-5-6-7-6-5-6-7-6-5-7-8-300-300-8-13-3-7-1-6v-13l4-13 6-9 7-8 12-7 7-2z"/>
                        <path transform="translate(2047,1009)" d="m0 0"/>
                        </svg>
                    </div>
                <p>DUROC</p>
                </div>
                <ul>
                <li>Duroc 1</li>
                <li>Duroc 2</li>
                <li>Ver todo</li>
                </ul>
            </div> -->

            <!-- Nivel 3: royal -->
            <!-- <div class="menu" id="menu-level-3-royal">
                <div class="title">
                    <div class="back-btn" data-back="#menu-level-2-porcino"><?xml version="1.0" encoding="UTF-8"?>
                        <svg version="1.1" viewBox="0 0 2048 2048" width="512" height="512" xmlns="http://www.w3.org/2000/svg">
                        <path transform="translate(1531,509)" d="m0 0h9l13 4 10 7 9 7 4 4v2h2v2h2v2h2v2h2l6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 7 8 23 23 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 7 8 9 13 4 9v25l-3 4-10 15-6 7-7 6-5 6-8 7-445 445-12 7-10 3-13 1-15-4-11-8-7-7-8-16-1-7v-12l4-13 6-9 13-15 373-373h2l1-3-1842-1-14-3-8-4-10-8-7-10-4-8-1-4v-20l4-9 6-10 6-7 11-7 15-4h1609l153-1h81l-7-8-14-14v-2l-4-2v-2l-4-2v-2l-4-2v-2l-4-2v-2l-4-2v-2h-2l-6-7-6-5-6-7-6-5-6-7-6-5-7-8-300-300-8-13-3-7-1-6v-13l4-13 6-9 7-8 12-7 7-2z"/>
                        <path transform="translate(2047,1009)" d="m0 0"/>
                        </svg>
                    </div>
                <p>ROYAL</p>
                </div>
                <ul>
                <li>ROYAL 1</li>
                <li>ROYAL 2</li>
                <li>Ver todo</li>
                </ul>
            </div> -->

            <!-- Nivel 3: royal -->
            <div class="menu" id="menu-level-3-iberico">
                <div class="title">
                    <div class="back-btn" data-back="#menu-level-2-porcino"><?xml version="1.0" encoding="UTF-8"?>
                        <svg version="1.1" viewBox="0 0 2048 2048" width="512" height="512" xmlns="http://www.w3.org/2000/svg">
                        <path transform="translate(1531,509)" d="m0 0h9l13 4 10 7 9 7 4 4v2h2v2h2v2h2v2h2l6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 7 8 23 23 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 7 8 9 13 4 9v25l-3 4-10 15-6 7-7 6-5 6-8 7-445 445-12 7-10 3-13 1-15-4-11-8-7-7-8-16-1-7v-12l4-13 6-9 13-15 373-373h2l1-3-1842-1-14-3-8-4-10-8-7-10-4-8-1-4v-20l4-9 6-10 6-7 11-7 15-4h1609l153-1h81l-7-8-14-14v-2l-4-2v-2l-4-2v-2l-4-2v-2l-4-2v-2l-4-2v-2h-2l-6-7-6-5-6-7-6-5-6-7-6-5-7-8-300-300-8-13-3-7-1-6v-13l4-13 6-9 7-8 12-7 7-2z"/>
                        <path transform="translate(2047,1009)" d="m0 0"/>
                        </svg>
                    </div>
                <p>ROYAL</p>
                </div>
                <ul>
                <li>ROYAL 1</li>
                <li>ROYAL 2</li>
                <li>Ver todo</li>
                </ul>
            </div>

            <!-- Nivel 3: casqueria-porcino -->
            <!-- <div class="menu" id="menu-level-3-casqueria-porcino">
                <div class="title">
                    <div class="back-btn" data-back="#menu-level-2-porcino"><?xml version="1.0" encoding="UTF-8"?>
                        <svg version="1.1" viewBox="0 0 2048 2048" width="512" height="512" xmlns="http://www.w3.org/2000/svg">
                        <path transform="translate(1531,509)" d="m0 0h9l13 4 10 7 9 7 4 4v2h2v2h2v2h2v2h2l6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 7 8 23 23 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 7 8 9 13 4 9v25l-3 4-10 15-6 7-7 6-5 6-8 7-445 445-12 7-10 3-13 1-15-4-11-8-7-7-8-16-1-7v-12l4-13 6-9 13-15 373-373h2l1-3-1842-1-14-3-8-4-10-8-7-10-4-8-1-4v-20l4-9 6-10 6-7 11-7 15-4h1609l153-1h81l-7-8-14-14v-2l-4-2v-2l-4-2v-2l-4-2v-2l-4-2v-2l-4-2v-2h-2l-6-7-6-5-6-7-6-5-6-7-6-5-7-8-300-300-8-13-3-7-1-6v-13l4-13 6-9 7-8 12-7 7-2z"/>
                        <path transform="translate(2047,1009)" d="m0 0"/>
                        </svg>
                    </div>
                <p>CASQUERIA PORCINO</p>
                </div>
                <ul>
                <li>CASQUERIA PORCINO 1</li>
                <li>CASQUERIA PORCINO 2</li>
                <li>Ver todo</li>
                </ul>
            </div> -->
      
        <!-- Nivel 2: Ovino -->
        <div class="menu" id="menu-level-2-ovino">
            <div class="title">
                <div class="back-btn" data-back="#menu-level-1"><?xml version="1.0" encoding="UTF-8"?>
                    <svg version="1.1" viewBox="0 0 2048 2048" width="512" height="512" xmlns="http://www.w3.org/2000/svg">
                    <path transform="translate(1531,509)" d="m0 0h9l13 4 10 7 9 7 4 4v2h2v2h2v2h2v2h2l6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 7 8 23 23 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 7 8 9 13 4 9v25l-3 4-10 15-6 7-7 6-5 6-8 7-445 445-12 7-10 3-13 1-15-4-11-8-7-7-8-16-1-7v-12l4-13 6-9 13-15 373-373h2l1-3-1842-1-14-3-8-4-10-8-7-10-4-8-1-4v-20l4-9 6-10 6-7 11-7 15-4h1609l153-1h81l-7-8-14-14v-2l-4-2v-2l-4-2v-2l-4-2v-2l-4-2v-2l-4-2v-2h-2l-6-7-6-5-6-7-6-5-6-7-6-5-7-8-300-300-8-13-3-7-1-6v-13l4-13 6-9 7-8 12-7 7-2z"/>
                    <path transform="translate(2047,1009)" d="m0 0"/>
                    </svg>
                </div>
              <p>OVINO</p>
            </div>
          <ul>
            <li data-target="#menu-level-3-lechazo">Lechazo<span>></span></li>
            <li data-target="#menu-level-3-recental">Recental<span>></span></li>
            <li data-target="#menu-level-3-cordero">Cordero<span>></span></li>
            <li data-target="#menu-level-3-casqueria-ovino">Casquería<span>></span></li>
          </ul>
        </div>

            <!-- Nivel 3: lechazo -->
            <!-- <div class="menu" id="menu-level-3-lechazo">
                <div class="title">
                    <div class="back-btn" data-back="#menu-level-2-ovino"><?xml version="1.0" encoding="UTF-8"?>
                        <svg version="1.1" viewBox="0 0 2048 2048" width="512" height="512" xmlns="http://www.w3.org/2000/svg">
                        <path transform="translate(1531,509)" d="m0 0h9l13 4 10 7 9 7 4 4v2h2v2h2v2h2v2h2l6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 7 8 23 23 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 7 8 9 13 4 9v25l-3 4-10 15-6 7-7 6-5 6-8 7-445 445-12 7-10 3-13 1-15-4-11-8-7-7-8-16-1-7v-12l4-13 6-9 13-15 373-373h2l1-3-1842-1-14-3-8-4-10-8-7-10-4-8-1-4v-20l4-9 6-10 6-7 11-7 15-4h1609l153-1h81l-7-8-14-14v-2l-4-2v-2l-4-2v-2l-4-2v-2l-4-2v-2l-4-2v-2h-2l-6-7-6-5-6-7-6-5-6-7-6-5-7-8-300-300-8-13-3-7-1-6v-13l4-13 6-9 7-8 12-7 7-2z"/>
                        <path transform="translate(2047,1009)" d="m0 0"/>
                        </svg>
                    </div>
                <p>lechazo</p>
                </div>
                <ul>
                <li>CASQUERIA PORCINO 1</li>
                <li>CASQUERIA PORCINO 2</li>
                <li>Ver todo</li>
                </ul>
            </div> -->

            <!-- Nivel 3: recental -->
            <!-- <div class="menu" id="menu-level-3-recental">
                <div class="title">
                    <div class="back-btn" data-back="#menu-level-2-ovino"><?xml version="1.0" encoding="UTF-8"?>
                        <svg version="1.1" viewBox="0 0 2048 2048" width="512" height="512" xmlns="http://www.w3.org/2000/svg">
                        <path transform="translate(1531,509)" d="m0 0h9l13 4 10 7 9 7 4 4v2h2v2h2v2h2v2h2l6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 7 8 23 23 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 7 8 9 13 4 9v25l-3 4-10 15-6 7-7 6-5 6-8 7-445 445-12 7-10 3-13 1-15-4-11-8-7-7-8-16-1-7v-12l4-13 6-9 13-15 373-373h2l1-3-1842-1-14-3-8-4-10-8-7-10-4-8-1-4v-20l4-9 6-10 6-7 11-7 15-4h1609l153-1h81l-7-8-14-14v-2l-4-2v-2l-4-2v-2l-4-2v-2l-4-2v-2l-4-2v-2h-2l-6-7-6-5-6-7-6-5-6-7-6-5-7-8-300-300-8-13-3-7-1-6v-13l4-13 6-9 7-8 12-7 7-2z"/>
                        <path transform="translate(2047,1009)" d="m0 0"/>
                        </svg>
                    </div>
                <p>recental</p>
                </div>
                <ul>
                <li>recental 1</li>
                <li>recental 2</li>
                <li>Ver todo</li>
                </ul>
            </div> -->

            <!-- Nivel 3: cordero -->
            <!-- <div class="menu" id="menu-level-3-cordero">
                <div class="title">
                    <div class="back-btn" data-back="#menu-level-2-ovino"><?xml version="1.0" encoding="UTF-8"?>
                        <svg version="1.1" viewBox="0 0 2048 2048" width="512" height="512" xmlns="http://www.w3.org/2000/svg">
                        <path transform="translate(1531,509)" d="m0 0h9l13 4 10 7 9 7 4 4v2h2v2h2v2h2v2h2l6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 7 8 23 23 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 7 8 9 13 4 9v25l-3 4-10 15-6 7-7 6-5 6-8 7-445 445-12 7-10 3-13 1-15-4-11-8-7-7-8-16-1-7v-12l4-13 6-9 13-15 373-373h2l1-3-1842-1-14-3-8-4-10-8-7-10-4-8-1-4v-20l4-9 6-10 6-7 11-7 15-4h1609l153-1h81l-7-8-14-14v-2l-4-2v-2l-4-2v-2l-4-2v-2l-4-2v-2l-4-2v-2h-2l-6-7-6-5-6-7-6-5-6-7-6-5-7-8-300-300-8-13-3-7-1-6v-13l4-13 6-9 7-8 12-7 7-2z"/>
                        <path transform="translate(2047,1009)" d="m0 0"/>
                        </svg>
                    </div>
                <p>cordero</p>
                </div>
                <ul>
                <li>cordero 1</li>
                <li>cordero 2</li>
                <li>Ver todo</li>
                </ul>
            </div> -->

            <!-- Nivel 3: casqueria-ovino -->
            <!-- <div class="menu" id="menu-level-3-casqueria-ovino">
                <div class="title">
                    <div class="back-btn" data-back="#menu-level-2-ovino"><?xml version="1.0" encoding="UTF-8"?>
                        <svg version="1.1" viewBox="0 0 2048 2048" width="512" height="512" xmlns="http://www.w3.org/2000/svg">
                        <path transform="translate(1531,509)" d="m0 0h9l13 4 10 7 9 7 4 4v2h2v2h2v2h2v2h2l6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 7 8 23 23 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 7 8 9 13 4 9v25l-3 4-10 15-6 7-7 6-5 6-8 7-445 445-12 7-10 3-13 1-15-4-11-8-7-7-8-16-1-7v-12l4-13 6-9 13-15 373-373h2l1-3-1842-1-14-3-8-4-10-8-7-10-4-8-1-4v-20l4-9 6-10 6-7 11-7 15-4h1609l153-1h81l-7-8-14-14v-2l-4-2v-2l-4-2v-2l-4-2v-2l-4-2v-2l-4-2v-2h-2l-6-7-6-5-6-7-6-5-6-7-6-5-7-8-300-300-8-13-3-7-1-6v-13l4-13 6-9 7-8 12-7 7-2z"/>
                        <path transform="translate(2047,1009)" d="m0 0"/>
                        </svg>
                    </div>
                <p>casqueria ovino</p>
                </div>
                <ul>
                <li>casqueria-ovino 1</li>
                <li>casqueria-ovino 2</li>
                <li>Ver todo</li>
                </ul>
            </div> -->
      
        <!-- Nivel 2: Caza -->
        <div class="menu" id="menu-level-2-caza">
            <div class="title">
                <div class="back-btn" data-back="#menu-level-1"><?xml version="1.0" encoding="UTF-8"?>
                    <svg version="1.1" viewBox="0 0 2048 2048" width="512" height="512" xmlns="http://www.w3.org/2000/svg">
                    <path transform="translate(1531,509)" d="m0 0h9l13 4 10 7 9 7 4 4v2h2v2h2v2h2v2h2l6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 7 8 23 23 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 5 6 7 6 7 8 9 13 4 9v25l-3 4-10 15-6 7-7 6-5 6-8 7-445 445-12 7-10 3-13 1-15-4-11-8-7-7-8-16-1-7v-12l4-13 6-9 13-15 373-373h2l1-3-1842-1-14-3-8-4-10-8-7-10-4-8-1-4v-20l4-9 6-10 6-7 11-7 15-4h1609l153-1h81l-7-8-14-14v-2l-4-2v-2l-4-2v-2l-4-2v-2l-4-2v-2l-4-2v-2h-2l-6-7-6-5-6-7-6-5-6-7-6-5-7-8-300-300-8-13-3-7-1-6v-13l4-13 6-9 7-8 12-7 7-2z"/>
                    <path transform="translate(2047,1009)" d="m0 0"/>
                    </svg>
                </div>
              <p>CAZA</p>
            </div>
          <!-- <ul>
            <li>Aves</li>
            <li>Jabalí</li>
            <li>Venado</li>
          </ul> -->
        </div>
      
        <!-- Nivel 2: Elaborados -->
        <!-- <div class="menu" id="menu-level-2-elaborados">
          <div class="back-btn" data-back="#menu-level-1">Atrás</div>
          <ul>
            <li>Elaborado 1</li>
            <li>Elaborado 2</li>
            <li>Elaborado 3</li>
            <li>Elaborado 4</li>
            <li>Elaborado 5</li>
            <li>Elaborado 6</li>
          </ul>
        </div> -->
      
        <!-- Nivel 2: Congelados -->
        <!-- <div class="menu" id="menu-level-2-congelados">
          <div class="back-btn" data-back="#menu-level-1">Atrás</div>
          <ul>
            <li>Conge 1</li>
            <li>Conge 2</li>
            <li>Conge 3</li>
            <li>Conge 4</li>
          </ul>
        </div> -->
      </div>

</header>
    `;

    // Añadir el contenedor al cuerpo del documento
    document.body.prepend(headerContainer);






// MENU MOBILE /////////////////////////////////////////////
const movilMenu = document.querySelector('.movil-menu');
const menuContainer = document.querySelector('.menu-container-movil');

// Evento para abrir/cerrar el menú principal
movilMenu.addEventListener('click', () => {
  const isVisible = menuContainer.classList.contains('active');

  if (!isVisible) {
    // Mostrar el menú móvil
    menuContainer.classList.add('active');
    movilMenu.classList.add('active');
    gsap.fromTo(
      menuContainer,
      { y: '-100%', opacity: 0 },
      { y: '0%', opacity: 1, duration: 0.5, ease: 'power1.out' }
    );
  } else {
    // Ocultar el menú móvil
    gsap.to(menuContainer, {
      y: '-100%',
      opacity: 0,
      duration: 0.5,
      ease: 'power1.in',
      onComplete: () => {
        menuContainer.classList.remove('active');
        movilMenu.classList.remove('active');
      },
    });
  }
});

// Lógica para avanzar en los submenús
document.querySelectorAll('.menu li').forEach((item) => {
  item.addEventListener('click', () => {
    const target = document.querySelector(item.dataset.target);
    if (target) {
      const currentMenu = document.querySelector('.menu.active');

      // Asegurar que el menú actual permanezca estático
      currentMenu.style.position = 'static';

      // Timeline para animar el submenú que entra
      const timeline = gsap.timeline({
        onComplete: () => {
          currentMenu.classList.remove('active');
          target.classList.add('active');
          currentMenu.style.position = ''; // Restaurar la posición
        },
      });

      timeline
        .add('start') // Etiqueta para sincronizar las animaciones
        .fromTo(
          target,
          { x: '100%', opacity: 1 },
          { x: '0%', opacity: 1, duration: 0.5, ease: 'power1.inOut' },
          'start' // Entrada del nuevo submenú
        );
    }
  });
});

// Lógica para retroceder en los submenús
document.querySelectorAll('.back-btn').forEach((btn) => {
  btn.addEventListener('click', () => {
    const back = document.querySelector(btn.dataset.back);
    if (back) {
      const currentMenu = document.querySelector('.menu.active');

      // Asegurar que el menú anterior permanezca estático
      back.style.position = 'static';

      // Timeline para animar el submenú que sale
      const timeline = gsap.timeline({
        onComplete: () => {
          currentMenu.classList.remove('active');
          back.classList.add('active');
          back.style.position = ''; // Restaurar la posición
        },
      });

      timeline
        .add('start') // Etiqueta para sincronizar las animaciones
        .fromTo(
          currentMenu,
          { x: '0%', opacity: 1 },
          { x: '100%', opacity: 1, duration: 0.5, ease: 'power1.inOut' },
          'start' // Salida del submenú actual
        )
        .fromTo(
          back,
          { x: '0%', opacity: 1 },
          { x: '0%', opacity: 1, duration: 0.5, ease: 'power1.inOut' },
          'start' // Entrada del menú anterior
        );
    }
  });
});



////////////////////////////////////////////////
///////////////// DESKTOP /////////////////////
///////////////////////////////////////////////


// Control de Categorias de familias
///////////////////////////////////////////////
const headerProductos = document.getElementById('header-productos');
const menuDesktop = document.querySelector('.menu-desktop');
const menuFamilias = document.querySelector('.menu-familias'); // Submenú dentro del contenedor

// Función para expandir el menú
function expandMenu() {
    menuDesktop.style.height = '116px'; // Expandimos solo el contenedor
    menuDesktop.style.transition = 'height 0.3s ease';
}

// Función para colapsar el menú
function collapseMenu() {
    menuDesktop.style.height = '77px'; // Colapsamos el contenedor
    menuDesktop.style.transition = 'height 0.3s ease';
}

// Expandir el menú al pasar el ratón sobre headerProductos, menuFamilias o submenús
headerProductos.addEventListener('mouseenter', expandMenu);
menuFamilias.addEventListener('mouseenter', expandMenu);
document.querySelectorAll('.submenu').forEach(subMenu => {
    subMenu.addEventListener('mouseenter', expandMenu);
});

// Colapsar el menú al salir de todas las áreas, incluido submenu
function checkAndCollapseMenu() {
    setTimeout(() => {
        if (
            !headerProductos.matches(':hover') &&
            !menuFamilias.matches(':hover') &&
            ![...document.querySelectorAll('.submenu')].some(subMenu =>
                subMenu.matches(':hover')
            )
        ) {
            collapseMenu();
            hideAllSubMenus(); // Oculta todos los submenús
        }
    }, 100);
}

headerProductos.addEventListener('mouseleave', checkAndCollapseMenu);
menuFamilias.addEventListener('mouseleave', checkAndCollapseMenu);
document.querySelectorAll('.submenu').forEach(subMenu => {
    subMenu.addEventListener('mouseleave', checkAndCollapseMenu);
});

// Despliegue de familias con efectos
///////////////////////////////////////////////
const menuItems = document.querySelectorAll('[data-target]');
const subMenus = document.querySelectorAll('.submenu');

// Función para mostrar el submenú con efecto
function showSubMenu(targetId) {
    // Ocultamos todos los submenús primero
    subMenus.forEach(subMenu => {
        subMenu.classList.remove('visible');
    });
    // Mostramos solo el submenú correspondiente
    const subMenu = document.getElementById(targetId);
    if (subMenu) {
        subMenu.classList.add('visible');
    }
}

// Función para ocultar todos los submenús con efecto
function hideAllSubMenus() {
    subMenus.forEach(subMenu => {
        subMenu.classList.remove('visible');
    });
}

// Evento para cada elemento del menú
menuItems.forEach(item => {
    item.addEventListener('mouseenter', () => {
        const targetId = item.getAttribute('data-target');
        showSubMenu(targetId);
    });
});

// Ocultamos los submenús cuando el ratón no está sobre el menú o el submenú
document.addEventListener('mouseleave', hideAllSubMenus);




});


