window.onload = function () {
    const videos = document.querySelectorAll("video");
    let loadedVideos = 0;
    const minimumLoadTime = 0; // 4 segundos
    let loaderTimeout;
  
    function checkVideosLoaded() {
      loadedVideos++;
      if (loadedVideos === videos.length) {
        clearTimeout(loaderTimeout);
        hideLoader();
      }
    }
  
    function hideLoader() {
      const loader = document.getElementById("loader");
      if (!loader) return; // Evita errores si el loader no existe
      loader.classList.add("fade-out");
  
      setTimeout(() => {
        loader.remove(); // Elimina el loader
        videos.forEach((video) => video.play());
      }, 500); // Tiempo para la animación
    }
  
    if (videos.length > 0) {
      videos.forEach((video) => {
        video.addEventListener("canplaythrough", checkVideosLoaded);
      });
    } else {
      console.warn("No se encontraron vídeos en la página.");
    }
  
    loaderTimeout = setTimeout(hideLoader, minimumLoadTime);
  };
  




gsap.registerPlugin(SplitText, TextPlugin, ScrollTrigger);

const loadText = document.querySelector('#loader p');
const loadLogo = document.querySelectorAll('#loader .load-logo svg');
const videoContainers = document.querySelectorAll('#video1, #video2, #video3');
const videowrap = document.querySelectorAll('.video');
const buttonContacto = document.querySelector('header .button');



const load = gsap.timeline({
    paused:false
});

load
    .fromTo(loadLogo, {
        y:220
    },
    {
        y:-0,
        duration:2,
        ease: 'back.inOut(1.7)',
    }, "-=0.3")
    .fromTo(loadText, {
        text: '',
    },
    {
        duration: 1.5,
        text: 'La Carne que Conoces, El Servicio que Esperas.',
        ease: "none"
    })

//Video aparece y salen titulos de debajo
const tl = gsap.timeline({
    paused:false
});

tl.add('start')

    .fromTo(videowrap, {
        y:-1000,
    },
    {
        y:0,
        duration:2.5,
        delay:5,
        ease: 'back.out(0.5)',
    },)

    .add('start2')
    .fromTo('.p1', {
        text: '',
    },
    {
        duration: 1,
        text: 'Oilasko <br>Berriak ®',
        ease: "none"
    },'start2')

    .fromTo('.p2', {
        text: '',
    },
    {
        duration: 1,
        text: 'PV (ESP)',
        ease: "none"
    },'start2')

    .fromTo('.p3', {
        text: '',
    },
    {
        duration: 1,
        text: '1987',
        ease: "none"
    },'start2')

    .fromTo('.p4', {
        text: '',
    },
    {
        duration: 1,
        text: 'Distribución Cárnica',
        ease: "none"
    },'start2')

    //animación de video para que muevan los contenedores
     .fromTo(videoContainers, {

         y: 0,
     }, {
         y: '-100%',
         delay: 1,
         duration: 2,
         ease: 'power1.inOut',
         onComplete: function() {
             gsap.fromTo(videoContainers, {
                 y: '-100%',
             }, {
                 y: '-200%',
                 duration: 2,
                 delay: 4,
                 ease: 'power1.inOut',
                 
             });
         }
     });
  

//MENU prodcutos destacas
document.addEventListener('DOMContentLoaded', () => {
const menuLinks = document.querySelectorAll('.category ul li a');
const sections = document.querySelectorAll('#aves1, #vacuno1, #porcino1, #ovino1');

// Función para mostrar la sección activa
const showSection = (targetId) => {
    sections.forEach((section) => {
        section.style.display = section.id === targetId ? 'block' : 'none';
    });

    menuLinks.forEach((link) => {
        link.classList.toggle('active', link.dataset.target === targetId);
    });
};

// Mostrar avees
showSection('aves1');

// que tire el menu
menuLinks.forEach((link) => {
    link.addEventListener('click', (event) => {
        event.preventDefault(); 
        const targetId = link.dataset.target; // atributo data-target
        showSection(targetId);
    });
});
});




//Contendero PODUCTOS OILASKO   
const productos = gsap.timeline({
    paused:false
});


productos
    //h2
    .fromTo(
        "#GASP-pro .intro h2", { 
            y: 50, 
            opacity: 0 
        },
        { 
            y: 0,
            opacity: 1,
            ease: "power1.out",
            scrollTrigger: {
                trigger: "#GASP-pro .intro", 
                start: "40% 80%", 
                end: "80% 80%",
                scrub: 3,
                markers: false, 
            }
        }
    )

    //Cards
    .fromTo(
        "#GASP-pro #carrusel", { 
            maxWidth:'990px',
            opacity: 0,
        },
        { 
            maxWidth:'1100px',
            opacity: 1,
            ease: "power1.out",
            scrollTrigger: {
                trigger: "#GASP-pro #carrusel", 
                start: "0% 80%", 
                end: "40% 80%",
                scrub: 3,
                markers: false, 
            }
        }
    )

    //button
    .fromTo(
        "#GASP-pro .green svg", { 
            x: -10,
            rotate:-90,
        },
        { 
            x: 10,
            ease: "power1.out",
            delay: 2,
            scrollTrigger: {
                trigger: "#GASP-pro .green", 
                start: "400% 90%", 
                end: "400% 90%",
                scrub: 4,
                markers: false,
            }
        });



//Contendero CONFIANZA Y TRAYECTORIA   
const confiP = new SplitText(".GASP-text p", { 
    type: "words,lines", 
    wordsClass: "wordsconfiP",
    linesClass: "linesconfiP"
  });

const confiYtray = gsap.timeline({
    paused:false
});

confiYtray

//h2
.fromTo(
    ".GASP-text h2", { 
        y: 50, 
        opacity: 0 
    },
    { 
        y: 0,
        opacity: 1,
        ease: "power1.out",
        scrollTrigger: {
            trigger: ".GASP-text h2", 
            start: "0% 80%", 
            end: "0% 80%",
            scrub: 3,
            markers: false, 
        }
    }
)

//p
.fromTo(
    ".linesconfiP", { 
        y: 50, 
        opacity: 0 
    },
    { 
        y: 0,
        opacity: 1,
        ease: "power1.out",
        stagger: {
            each:0.025,
            from:"start"
        },
        scrollTrigger: {
            trigger: ".GASP-text p", 
            start: "0% 80%", 
            end: "0% 80%",
            scrub: 3,
            markers: false, 
        }
    }
)

function setupCarruselAnimations() {
    // Identificador único para las animaciones del carrusel
    const carruselTriggers = ScrollTrigger.getAll().filter(trigger =>
        ["carrusel-left", "carrusel-right"].includes(trigger.vars.id)
    );

    // Limpia solo las animaciones del carrusel
    carruselTriggers.forEach(trigger => trigger.kill());

    if (window.matchMedia("(min-width: 1020px)").matches) {
        // Animaciones verticales para pantallas menores a 1020px
        gsap.to(".carrusel.left img", {
            y: -1000,
            ease: "power3.out",
            scrollTrigger: {
                id: "carrusel-left", // Identificador único para esta animación
                trigger: ".wrap-carrusel",
                start: "top bottom",
                end: "bottom top",
                scrub: 4,
                markers: false
            }
        });

        gsap.to(".carrusel.right img", {
            y: 1000,
            ease: "power3.out",
            scrollTrigger: {
                id: "carrusel-right", // Identificador único para esta animación
                trigger: ".wrap-carrusel",
                start: "top bottom",
                end: "bottom top",
                scrub: 4,
                markers: false
            }
        });
    } else {
        // Animaciones horizontales para pantallas mayores a 1020px
        gsap.to(".carrusel.left img", {
            x: -1000,
            ease: "power3.out",
            scrollTrigger: {
                id: "carrusel-left", // Identificador único para esta animación
                trigger: ".wrap-carrusel",
                start: "top bottom",
                end: "bottom top",
                scrub: 4,
                markers: false
            }
        });

        gsap.to(".carrusel.right img", {
            x: 1000,
            ease: "power3.out",
            scrollTrigger: {
                id: "carrusel-right", // Identificador único para esta animación
                trigger: ".wrap-carrusel",
                start: "top bottom",
                end: "bottom top",
                scrub: 4,
                markers: false
            }
        });
    }
}

// Configuración inicial y escucha de cambios de tamaño de ventana
setupCarruselAnimations();
window.addEventListener("resize", setupCarruselAnimations);



//////////////////////////////////////
///////////SERVICIOS-PARRAFOS/////////
/////////////////////////////////////

//SERVI 2
const servi2pf = new SplitText(".servi2 .first p", { 
    type: "words,lines", 
    wordsClass: "wordservi2pf",
    linesClass: "lineservi2p"
  });

const servi2ps = new SplitText(".servi2 .second p", { 
    type: "words,lines", 
    wordsClass: "wordservi2ps",
    linesClass: "lineservi2p"
    });

const servi2pt = new SplitText(".servi2 .third p", { 
    type: "words,lines", 
    wordsClass: "wordservi2pt",
    linesClass: "lineservi2p"
    });

//Contendero PODUCTOS OILASKO   
const servi2 = gsap.timeline({
    paused:false
});


servi2
    .fromTo(
        ".servi2 .first, .servi2 .second, .servi2 .third", { 
            y: 50, 
            opacity: 0 
        },
        { 
            y: 0,
            opacity: 1,
            ease: "power1.out",
            scrollTrigger: {
                trigger: ".servi2 .picture", 
                start: "20% 80%", 
                end: "20% 80%",
                scrub: 2,
                markers: false, 
            },
        })
    .fromTo(
        ".wordservi2pf, .wordservi2ps, .wordservi2pt", { 
            y: 50, 
        },
        { 
            y: 0,
            ease: "power1.out",
            stagger: {
                each: 0.01,
                from: "start",
            },
            scrollTrigger: {
                trigger: ".servi2 .picture", 
                start: "15% 80%", 
                end: "15% 80%",
                scrub: 2,
                markers: false, 
            }
        }
    )
    ////// clear all ////
    .fromTo(
        ".servi2 .first, .servi2 .second, .servi2 .third", { 
            y: 0, 
        },
        { 
            y: 50,
            opacity: 0,
            ease: "power1.out",
            scrollTrigger: {
                trigger: ".servi2 .picture", 
                start: "110% 80%", 
                end: "110% 80%",
                scrub: 2,
                markers: false, 
            },
            
        },)

 


//SERVI 1
const servi1pf = new SplitText(".servi1 .first p", { 
    type: "words,lines", 
    wordsClass: "wordservi1pf",
    linesClass: "lineservi1p"
    });

const servi1ps = new SplitText(".servi1 .second p", { 
    type: "words,lines", 
    wordsClass: "wordservi1ps",
    linesClass: "lineservi1p"
    });

const servi1pt = new SplitText(".servi1 .third p", { 
    type: "words,lines", 
    wordsClass: "wordservi1pt",
    linesClass: "lineservi1p"
    });

//Contendero PODUCTOS OILASKO   
const servi1 = gsap.timeline({
    paused:false
    });


servi1
    .fromTo(
        ".servi1 .first, .servi1 .second", { 
            y: 50, 
            opacity: 0 
        },
        { 
            y: 0,
            opacity: 1,
            ease: "power1.out",
            scrollTrigger: {
                trigger: ".servi1 .picture", 
                start: "45% 65%", 
                end: "45% 65%",
                scrub: 2,
                markers: false, 
            },
        })
    .fromTo(
        ".wordservi1pf, .wordservi1ps", { 
            y: 50, 
        },
        { 
            y: 0,
            ease: "power1.out",
            stagger: {
                each: 0.01,
                from: "start",
            },
            scrollTrigger: {
                trigger: ".servi1 .picture", 
                start: "45% 65%", 
                end: "45% 65%",
                scrub: 2,
                markers: false, 
            }
        }
    )

    ////// clear all ////
    .fromTo(
        ".servi1 .first, .servi1 .second", { 
            y: 0, 
        },
        { 
            y: 50,
            opacity: 0,
            ease: "power1.out",
            scrollTrigger: {
                trigger: ".servi1 .picture", 
                start: "110% 65%", 
                end: "110% 65%",
                scrub: 2,
                markers: false, 
            },
            
        },)




//SERVI 4
const servi4pf = new SplitText(".servi4 .first p", { 
    type: "words,lines", 
    wordsClass: "wordservi4pf",
    linesClass: "lineservi4p"
    });

const servi4ps = new SplitText(".servi4 .second p", { 
    type: "words,lines", 
    wordsClass: "wordservi4ps",
    linesClass: "lineservi4p"
    });

const servi4pt = new SplitText(".servi4 .third p", { 
    type: "words,lines", 
    wordsClass: "wordservi4pt",
    linesClass: "lineservi4p"
    });

//Contendero PODUCTOS OILASKO   
const servi4 = gsap.timeline({
    paused:false
    });

servi4

    .fromTo(
        ".servi4 .first, .servi4 .second", { 
            y: 50, 
            opacity: 0 
        },
        { 
            y: 0,
            opacity: 1,
            ease: "power1.out",
            scrollTrigger: {
                trigger: ".servi4 .picture", 
                start: "45% 65%", 
                end: "45% 65%",
                scrub: 2,
                markers: false, 
            },
        })
    .fromTo(
        ".wordservi4pf .wordservi4ps", { 
            y: 50, 
        },
        { 
            y: 0,
            ease: "power1.out",
            stagger: {
                each: 0.01,
                from: "start",
            },
            scrollTrigger: {
                trigger: ".servi4 .picture", 
                start: "45% 65%", 
                end: "45% 65%",
                scrub: 2,
                markers: false, 
            }
        }
    )

////// clear all ////
    .fromTo(
        ".servi4 .first, .servi4 .second", { 
            y: 0, 
        },
        { 
            y: 50,
            opacity: 0,
            ease: "power1.out",
            scrollTrigger: {
                trigger: ".servi4 .picture",  
                start: "110% 65%", 
                end: "110% 65%",
                scrub: 2,
                markers: false, 
            },
            
        },)


//SERVI 3
const servi3pf = new SplitText(".servi3 .first p", { 
    type: "words,lines", 
    wordsClass: "wordservi3pf",
    linesClass: "lineservi3p"
  });

const servi3ps = new SplitText(".servi3 .second p", { 
    type: "words,lines", 
    wordsClass: "wordservi3ps",
    linesClass: "lineservi3p"
    });

const servi3pt = new SplitText(".servi3 .third p", { 
    type: "words,lines", 
    wordsClass: "wordservi3pt",
    linesClass: "lineservi3p"
    });

//Contendero PODUCTOS OILASKO   
const servi3 = gsap.timeline({
    paused:false
});

servi3   
    .fromTo(
        ".servi3 .first, .servi3 .second, .servi3 .third", { 
            y: 50, 
            opacity: 0 
        },
        { 
            y: 0,
            opacity: 1,
            ease: "power1.out",
            scrollTrigger: {
                trigger: ".servi3 .picture", 
                start: "15% 60%", 
                end: "15% 60%",
                scrub: 2,
                markers: false, 
            },
        })
    .fromTo(
        ".wordservi3pf, wordservi3ps, wordservi3pt", { 
            y: 50, 
        },
        { 
            y: 0,
            ease: "power1.out",
            stagger: {
                each: 0.01,
                from: "start",
            },
            scrollTrigger: {
                trigger: ".servi3 .picture", 
                start: "15% 60%", 
                end: "15% 60%",
                scrub: 2,
                markers: false, 
            }
        }
    )

    ////// clear all ////
    .fromTo(
        ".servi3 .first, .servi3 .second, .servi3 .third", { 
            y: 0, 
        },
        { 
            y: 50,
            opacity: 0,
            ease: "power1.out",
            scrollTrigger: {
                trigger: ".servi3 .picture", 
                start: "110% 60%", 
                end: "110% 60%",
                scrub: 2,
                markers: false, 
            },
            
        },)


//Zona geográfica & expansión  
const zonaP = new SplitText(".zona p", { 
    type: "words,lines", 
    wordsClass: "wordsZonaP",
    linesClass: "linesZonaP"
  });

const geoExpan = gsap.timeline({
    paused:false
});

geoExpan

//h2
.fromTo(
    ".zona h2", { 
        y: 50, 
        opacity: 0 
    },
    { 
        y: 0,
        opacity: 1,
        ease: "power1.out",
        scrollTrigger: {
            trigger: ".zona h2", 
            start: "0% 80%", 
            end: "0% 80%",
            scrub: 3,
            markers: false, 
        }
    }
)

//p
.fromTo(
    ".linesZonaP", { 
        y: 50, 
        opacity: 0 
    },
    { 
        y: 0,
        opacity: 1,
        ease: "power1.out",
        stagger: {
            each:0.025,
            from:"start"
        },
        scrollTrigger: {
            trigger: ".zona p", 
            start: "0% 80%", 
            end: "0% 80%",
            scrub: 3,
            markers: false, 
        }
    }
)




// CATALOGO Scroll lateral
const categorias = document.querySelectorAll('.categorias .categoria');

ScrollTrigger.matchMedia({
    // Condición para pantallas más grandes (por ejemplo, >1020px)
    "(min-width: 1021px)": function() {
        categorias.forEach((categoria, index) => {
            gsap.fromTo(
                categoria,
                { x: '50%' },
                {
                    x: '-120%',
                    ease: "power1.out",
                    scrollTrigger: {
                        trigger: ".categorias",
                        start: "30% center",
                        end: "bottom center",
                        scrub: 2,
                        markers: false,
                    },
                }
            );
        });
    },

    // Condición para pantallas más pequeñas (por ejemplo, <=1020px)
    "(max-width: 1020px)": function() {
        // Desactivar animación o aplicar otra lógica
        categorias.forEach((categoria) => {
            gsap.set(categoria, { clearProps: "all" }); // Elimina cualquier transformación de GSAP
        });
    }
});




// Selecciona todos los contenedores FAQ
document.querySelectorAll('.wrap-faq').forEach(faq => {
    const expanButton = faq.querySelector('.expan');

    expanButton.addEventListener('click', () => {
        const isExpanded = faq.classList.contains('expanded');
        
        // Cierra cualquier FAQ que esté abierta
        document.querySelectorAll('.wrap-faq.expanded').forEach(openFaq => {
            if (openFaq !== faq) {
                openFaq.style.maxHeight = '46px'; // Colapsa las otras FAQ
                openFaq.classList.remove('expanded');
            }
        });

        // Alterna el estado del contenedor actual
        if (isExpanded) {
            faq.style.maxHeight = '46px'; // Colapsa el actual
        } else {
            const contentHeight = faq.scrollHeight;       
            faq.style.maxHeight = `${contentHeight}px`; 
        }

        faq.classList.toggle('expanded');
    });
});


